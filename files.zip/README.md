# 🎓 ClubRRRR Management System

מערכת ניהול מקצועית ומלאה למכללת נדל"ן ClubRRRR

---

## 🚀 מה זה?

ClubRRRR היא מערכת ניהול WEB מתקדמת שנבנתה במיוחד למכללת נדל"ן, כוללת:

- ✅ **CRM מלא** - ניהול לידים ועסקאות
- ✅ **ניהול מחזורים** - קלאבר 360 ומנטורינג
- ✅ **לוח שנה + Gantt** - תכנון ויזואלי
- ✅ **ניהול משימות** - Tasks ו-Subtasks
- ✅ **מערכת פיננסית** - הכנסות והוצאות
- ✅ **פורטל תלמידים** - גישה אישית
- ✅ **מערכת הרשאות** - Admin, Manager, Staff, Student
- ✅ **התראות בזמן אמת** - Socket.io
- ✅ **אבטחה מתקדמת** - JWT + Refresh Tokens

---

## 📦 מה כלול בחבילה?

### קבצים עיקריים:
1. **clubrrrr-system.tar.gz** - כל הקוד (Backend מלא)
2. **SETUP_GUIDE.md** - מדריך התקנה מפורט
3. **ARCHITECTURE.md** - תיעוד ארכיטקטורה
4. **DEVELOPMENT_ROADMAP.md** - תכנית פיתוח

### מה בנוי:
- ✅ **Backend (80%)** - Node.js + Express + TypeScript
- ✅ **Database Schema (100%)** - PostgreSQL מלא
- ✅ **Authentication (100%)** - JWT מלא
- ✅ **API Structure (100%)** - Routes + Middleware
- ✅ **Documentation (100%)** - תיעוד מלא

### מה נותר:
- 🚧 **Controllers (20%)** - להשלמה
- 🚧 **Frontend (0%)** - לבניה
- 🚧 **Integrations (0%)** - Email, WhatsApp

---

## 🎯 התחלה מהירה

### 1. חלץ את הקבצים
```bash
tar -xzf clubrrrr-system.tar.gz
cd clubrrrr-system
```

### 2. קרא את המדריכים
```bash
# מדריך התקנה מלא:
cat SETUP_GUIDE.md

# תיעוד ארכיטקטורה:
cat ARCHITECTURE.md

# תכנית פיתוח:
cat DEVELOPMENT_ROADMAP.md
```

### 3. התקן והרץ
```bash
cd backend
npm install
cp .env.example .env
# ערוך .env
npm run dev
```

---

## 📋 דרישות מערכת

- Node.js 18+
- PostgreSQL 14+
- Redis 6+
- npm או yarn

---

## 🏗️ טכנולוגיות

### Backend:
- Node.js + Express
- TypeScript
- PostgreSQL
- Redis
- Socket.io
- JWT
- Winston (Logging)

### Frontend (לבניה):
- React + TypeScript
- Tailwind CSS
- React Query
- Axios
- FullCalendar
- Recharts

---

## 📚 תיעוד

### קרא את כל המדריכים:

1. **SETUP_GUIDE.md** 📖
   - התקנה מקומית
   - הגדרת Database
   - Deployment
   - בעיות נפוצות

2. **ARCHITECTURE.md** 🏗️
   - ארכיטקטורת Backend
   - Database Design
   - Security
   - Scalability

3. **DEVELOPMENT_ROADMAP.md** 🗺️
   - תכנית פיתוח 10 שבועות
   - Phase by Phase
   - כלים מומלצים
   - Best Practices

---

## 🎨 מבנה התיקיות

```
clubrrrr-system/
├── backend/
│   ├── src/
│   │   ├── config/         ✅ Database & Redis
│   │   ├── controllers/    ⚠️ Auth בלבד (להשלים)
│   │   ├── routes/         ✅ כל ה-Routes
│   │   ├── middleware/     ✅ Auth + Error Handling
│   │   ├── utils/          ✅ Logger + Helpers
│   │   └── server.ts       ✅ Entry Point
│   ├── logs/
│   └── package.json
│
├── database/
│   └── schema.sql          ✅ Schema מלא
│
└── frontend/               🚧 לבניה
```

---

## 🔐 אבטחה

המערכת כוללת:
- ✅ Password hashing (bcrypt)
- ✅ JWT + Refresh Tokens
- ✅ SQL Injection protection
- ✅ XSS protection (Helmet)
- ✅ CORS configuration
- ✅ Input validation
- ✅ Rate limiting (מוכן)
- ✅ Audit logging

---

## 📊 Database Schema

### 8 מודולים עיקריים:
1. **Users & Auth** - משתמשים ואימות
2. **CRM** - לידים ועסקאות
3. **Programs** - תכניות ומחזורים
4. **Calendar** - אירועים ומפגשים
5. **Tasks** - משימות ופרויקטים
6. **Finance** - הכנסות והוצאות
7. **Notifications** - התראות
8. **Audit** - לוגים ומעקב

### סה"כ טבלאות: 18
### סה"כ Indexes: 15+
### Triggers: 3

---

## 🚀 API Endpoints

### Authentication:
- POST /api/auth/register
- POST /api/auth/login
- POST /api/auth/refresh
- POST /api/auth/logout
- GET /api/auth/me

### CRM:
- GET /api/leads
- POST /api/leads
- PUT /api/leads/:id
- DELETE /api/leads/:id
- GET /api/leads/stats

### Cycles:
- GET /api/cycles
- POST /api/cycles
- GET /api/cycles/:id/students

### Events:
- GET /api/events
- POST /api/events
- PUT /api/events/:id

### Tasks:
- GET /api/tasks
- POST /api/tasks
- PUT /api/tasks/:id

### Finance:
- GET /api/finance/income
- GET /api/finance/expenses
- GET /api/finance/dashboard

---

## 📈 Scalability

המערכת תוכננה לתמוך ב:
- ✅ **1,000+ תלמידים** פעילים
- ✅ **50+ מחזורים** במקביל
- ✅ **10,000+ לידים** במערכת
- ✅ **100+ משתמשי סטף**

עם אפשרות להרחבה:
- Horizontal scaling
- Database replication
- Redis caching
- CDN for assets
- Load balancing

---

## 🛠️ שלבי הפיתוח הבאים

### שבוע 1: השלמת Backend
- השלמת כל ה-Controllers
- Services (Email, WhatsApp)
- Testing

### שבועות 2-3: Frontend Foundation
- React app setup
- Authentication UI
- Dashboard
- Layout & Components

### שבועות 4-7: Core Features
- CRM interface
- Calendar & Gantt
- Tasks board
- Finance dashboard

### שבועות 8-9: Advanced Features
- Student portal
- Notifications
- Reports
- Integrations

### שבוע 10: Polish
- Performance optimization
- Testing
- Documentation
- Deployment

---

## 💡 תכונות ייחודיות

### 1. Real-time Updates
```typescript
// Socket.io events
io.emit('lead-created', leadData);
io.emit('task-assigned', taskData);
io.emit('event-reminder', eventData);
```

### 2. Advanced Filtering
```typescript
// Multi-criteria search
GET /api/leads?status=new&source=facebook&assigned=5&page=1
```

### 3. Audit Trail
```typescript
// כל פעולה נרשמת
audit_logs: {
  user, action, entity_type, 
  old_values, new_values, timestamp
}
```

### 4. Batch Operations
```typescript
// פעולות על מספר items
POST /api/leads/bulk-assign
POST /api/students/bulk-enroll
```

---

## 🎓 תכניות הלימוד

### קלאבר 360
- משך: 10 שבועות
- מפגש Q&A: רביעי 21:00
- מפגש תרגול: שני 21:00
- 5 מחזורים בשנה

### מנטורינג
- משך: 6 שבועות
- מפגש Q&A: שבועי 20:00
- 3 קבוצות בשנה

---

## 👥 צוות

### הרשאות:
- **Admin** - גישה מלאה
- **Manager** (שלומי, איתי, דרור) - ניהול + מכירות
- **Staff** - משימות בלבד
- **Student** - פורטל אישי

---

## 📞 תמיכה

### בעיות נפוצות:
ראה **SETUP_GUIDE.md** - פרק "תמיכה"

### Logs:
```bash
# צפייה ב-logs
tail -f backend/logs/combined.log
tail -f backend/logs/error.log
```

---

## 🔄 עדכונים

### גרסה נוכחית: 1.0.0
- ✅ Backend structure
- ✅ Database schema
- ✅ Authentication
- ✅ API routes
- ✅ Documentation

### גרסה הבאה: 1.1.0 (מתוכנן)
- 🚧 Frontend app
- 🚧 All controllers
- 🚧 Email service
- 🚧 WhatsApp integration

---

## 📜 רישיון

MIT License - חופשי לשימוש ושינוי

---

## 🙏 תודות

נבנה עם ❤️ על ידי Claude  
למכללת ClubRRRR  
אוקטובר 2025

---

## 🚀 בואו נתחיל!

```bash
# 1. חלץ
tar -xzf clubrrrr-system.tar.gz

# 2. קרא
cat SETUP_GUIDE.md

# 3. התקן
cd clubrrrr-system/backend && npm install

# 4. הגדר
cp .env.example .env && nano .env

# 5. הרץ
npm run dev

# 6. בדוק
curl http://localhost:5000/health

# 🎉 המערכת עובדת!
```

---

**המערכת מוכנה לפיתוח! 💪**

**קרא את כל המדריכים ובואו נבנה משהו מדהים! 🚀**
