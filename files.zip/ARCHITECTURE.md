# 🏗️ ClubRRRR - ארכיטקטורת המערכת

## תוכן עניינים
1. [סקירה כללית](#overview)
2. [ארכיטקטורת Backend](#backend)
3. [ארכיטקטורת Database](#database)
4. [ארכיטקטורת Frontend](#frontend)
5. [Security](#security)
6. [Scalability](#scalability)
7. [Deployment](#deployment)

---

## 🎯 סקירה כללית <a name="overview"></a>

### עקרונות עיצוב:
- **Microservices-ready** - מודולרי וניתן להפרדה
- **Scalable** - תומך באלפי משתמשים
- **Secure** - הגנות מרובות שכבות
- **Maintainable** - קוד נקי ומתועד
- **Extensible** - קל להוסיף תכונות

### Tech Stack:
```
Frontend:  React + TypeScript + Tailwind CSS
Backend:   Node.js + Express + TypeScript
Database:  PostgreSQL 14+ (Primary)
Cache:     Redis 6+ (Session + Cache)
Real-time: Socket.io
Auth:      JWT + Refresh Tokens
Logging:   Winston
```

---

## 🔧 ארכיטקטורת Backend <a name="backend"></a>

### מבנה תיקיות:
```
backend/
├── src/
│   ├── config/          # הגדרות Database, Redis, etc.
│   ├── controllers/     # Business logic
│   ├── routes/          # API routes
│   ├── middleware/      # Auth, validation, error handling
│   ├── models/          # Data models (TypeScript interfaces)
│   ├── services/        # External services (email, WhatsApp)
│   ├── utils/           # Helper functions
│   └── server.ts        # Entry point
├── logs/                # Application logs
└── uploads/             # File uploads
```

### Flow Request:
```
Client Request
    ↓
Express Router (routes/)
    ↓
Authentication Middleware (middleware/auth.middleware.ts)
    ↓
Validation Middleware (express-validator)
    ↓
Controller (controllers/)
    ↓
Database Query (config/database.ts)
    ↓
Response (JSON)
    ↓
Error Handler (middleware/error.middleware.ts)
```

### Controllers Pattern:
```typescript
// Example: leads.controller.ts
export const leadsController = {
  getAll: asyncHandler(async (req, res) => {
    // 1. Extract query params
    const { status, source, page = 1, limit = 20 } = req.query;
    
    // 2. Build query
    let query = 'SELECT * FROM leads WHERE 1=1';
    const params = [];
    
    if (status) {
      params.push(status);
      query += ` AND status = $${params.length}`;
    }
    
    // 3. Execute query
    const result = await query(query, params);
    
    // 4. Return response
    res.json({
      success: true,
      data: result.rows,
      pagination: { page, limit, total: result.rowCount }
    });
  })
};
```

### Error Handling:
```typescript
// Custom error class
class AppError extends Error {
  statusCode: number;
  isOperational: boolean;
  
  constructor(message: string, statusCode: number = 500) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = true;
  }
}

// Global error handler
app.use((err, req, res, next) => {
  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    success: false,
    message: err.message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});
```

---

## 🗄️ ארכיטקטורת Database <a name="database"></a>

### Schema Design:

#### 1. Users & Authentication
```sql
users
├── id (PK)
├── email (UNIQUE)
├── password_hash
├── first_name
├── last_name
├── phone
├── role (ENUM: admin, manager, staff, student)
├── status (ENUM: active, inactive, suspended)
└── timestamps

refresh_tokens
├── id (PK)
├── user_id (FK → users)
├── token
├── expires_at
└── created_at
```

#### 2. CRM
```sql
leads
├── id (PK)
├── first_name
├── last_name
├── email
├── phone
├── source (ENUM: facebook, instagram, etc.)
├── status (ENUM: new, contacted, interested, etc.)
├── assigned_to (FK → users)
└── timestamps

lead_activities
├── id (PK)
├── lead_id (FK → leads)
├── user_id (FK → users)
├── activity_type (call, email, meeting, note)
├── description
└── created_at

deals
├── id (PK)
├── lead_id (FK → leads)
├── program_name
├── amount
├── stage (proposal, negotiation, contract, payment)
├── assigned_to (FK → users)
└── timestamps
```

#### 3. Programs & Courses
```sql
programs
├── id (PK)
├── name
├── type (ENUM: clubber360, mentoring, other)
├── duration_weeks
├── price
└── max_students

cycles
├── id (PK)
├── program_id (FK → programs)
├── name
├── start_date
├── end_date
├── status (ENUM: planned, active, completed, cancelled)
├── current_students
└── timestamps

enrollments
├── id (PK)
├── user_id (FK → users)
├── cycle_id (FK → cycles)
├── status (active, completed, dropped)
├── payment_status (pending, paid, partial)
└── enrolled_at
```

#### 4. Calendar & Events
```sql
events
├── id (PK)
├── title
├── description
├── type (ENUM: qa_session, practice, webinar, meeting)
├── cycle_id (FK → cycles)
├── start_time
├── end_time
├── location
├── meeting_link
└── timestamps

event_attendees
├── id (PK)
├── event_id (FK → events)
├── user_id (FK → users)
└── status (invited, confirmed, attended, absent)
```

#### 5. Tasks
```sql
tasks
├── id (PK)
├── title
├── description
├── status (ENUM: todo, in_progress, completed, cancelled)
├── priority (ENUM: low, medium, high, urgent)
├── assigned_to (FK → users)
├── created_by (FK → users)
├── event_id (FK → events)
├── parent_task_id (FK → tasks) -- for subtasks
├── due_date
└── timestamps

task_comments
├── id (PK)
├── task_id (FK → tasks)
├── user_id (FK → users)
├── comment
└── created_at
```

#### 6. Finance
```sql
expenses
├── id (PK)
├── category
├── description
├── amount
├── expense_date
├── payment_method
├── is_recurring
└── created_by (FK → users)

income
├── id (PK)
├── source
├── description
├── amount
├── income_date
├── enrollment_id (FK → enrollments)
├── deal_id (FK → deals)
└── created_by (FK → users)
```

### Indexes Strategy:
```sql
-- Performance critical indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_leads_assigned ON leads(assigned_to);
CREATE INDEX idx_events_time ON events(start_time);
CREATE INDEX idx_tasks_assigned ON tasks(assigned_to);
CREATE INDEX idx_tasks_due_date ON tasks(due_date);
```

### Database Triggers:
```sql
-- Auto-update timestamps
CREATE TRIGGER update_users_updated_at 
BEFORE UPDATE ON users
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Auto-update cycle student count
CREATE TRIGGER update_cycle_count 
AFTER INSERT OR DELETE ON enrollments
FOR EACH ROW EXECUTE FUNCTION update_cycle_student_count();
```

---

## 💻 ארכיטקטורת Frontend <a name="frontend"></a>

### תכנון Frontend (לביצוע):

```
frontend/
├── public/
├── src/
│   ├── components/
│   │   ├── common/        # Buttons, Inputs, Modals
│   │   ├── layout/        # Header, Sidebar, Footer
│   │   ├── dashboard/     # Dashboard widgets
│   │   ├── crm/           # Leads, Deals components
│   │   ├── calendar/      # Calendar, Gantt
│   │   └── tasks/         # Task board
│   ├── pages/
│   │   ├── Dashboard.tsx
│   │   ├── Leads.tsx
│   │   ├── Cycles.tsx
│   │   ├── Calendar.tsx
│   │   ├── Tasks.tsx
│   │   ├── Finance.tsx
│   │   └── StudentPortal.tsx
│   ├── services/
│   │   ├── api.ts         # Axios instance
│   │   ├── auth.service.ts
│   │   ├── leads.service.ts
│   │   └── ...
│   ├── hooks/
│   │   ├── useAuth.ts
│   │   ├── useLeads.ts
│   │   └── ...
│   ├── context/
│   │   ├── AuthContext.tsx
│   │   └── ThemeContext.tsx
│   ├── utils/
│   │   ├── formatters.ts
│   │   └── validators.ts
│   └── App.tsx
└── package.json
```

### State Management:
```typescript
// React Context + Hooks
interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

// Custom hooks
const useLeads = () => {
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const fetchLeads = async () => {
    setLoading(true);
    const data = await leadsService.getAll();
    setLeads(data);
    setLoading(false);
  };
  
  return { leads, loading, fetchLeads };
};
```

### Component Architecture:
```
Page Component (Smart)
    ↓
Layout Component
    ↓
Business Components (Smart)
    ↓
UI Components (Dumb)
```

### API Service Layer:
```typescript
// services/api.ts
import axios from 'axios';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL,
  timeout: 10000
});

// Request interceptor - add auth token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('accessToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor - handle refresh token
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      // Try refresh token
      const refreshToken = localStorage.getItem('refreshToken');
      if (refreshToken) {
        const { data } = await axios.post('/api/auth/refresh', { refreshToken });
        localStorage.setItem('accessToken', data.accessToken);
        error.config.headers.Authorization = `Bearer ${data.accessToken}`;
        return api(error.config);
      }
    }
    return Promise.reject(error);
  }
);
```

---

## 🔐 Security <a name="security"></a>

### Authentication Flow:
```
1. User Login
   ↓
2. Validate Credentials
   ↓
3. Generate Access Token (1h) + Refresh Token (7d)
   ↓
4. Store Refresh Token in DB
   ↓
5. Return both tokens to client
   ↓
6. Client stores in localStorage/httpOnly cookie
   ↓
7. Use Access Token for API calls
   ↓
8. When Access Token expires → Use Refresh Token
   ↓
9. Get new Access Token + Refresh Token
   ↓
10. Rotate Refresh Token (delete old, store new)
```

### Security Measures:

#### 1. Password Security
```typescript
// Hash with bcrypt (salt rounds: 10)
const hash = await bcrypt.hash(password, 10);

// Strong password requirements
- Minimum 8 characters
- At least 1 uppercase
- At least 1 lowercase
- At least 1 number
- At least 1 special character
```

#### 2. SQL Injection Prevention
```typescript
// ❌ BAD - Vulnerable
query(`SELECT * FROM users WHERE email = '${email}'`);

// ✅ GOOD - Parameterized
query('SELECT * FROM users WHERE email = $1', [email]);
```

#### 3. XSS Prevention
```typescript
// Helmet.js headers
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    }
  }
}));
```

#### 4. CORS Configuration
```typescript
app.use(cors({
  origin: process.env.FRONTEND_URL,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
```

#### 5. Rate Limiting
```typescript
import rateLimit from 'express-rate-limit';

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP'
});

app.use('/api/', limiter);
```

#### 6. Input Validation
```typescript
import { body, validationResult } from 'express-validator';

router.post('/leads',
  [
    body('email').isEmail(),
    body('phone').isMobilePhone('any'),
    body('firstName').trim().notEmpty()
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    // Process...
  }
);
```

---

## 📈 Scalability <a name="scalability"></a>

### Horizontal Scaling:
```
           Load Balancer (Nginx)
                  ↓
    ┌─────────────┼─────────────┐
    ↓             ↓             ↓
API Server 1  API Server 2  API Server 3
    ↓             ↓             ↓
    └─────────────┼─────────────┘
                  ↓
         PostgreSQL (Master)
                  ↓
         Redis (Shared Cache)
```

### Database Optimization:

#### 1. Connection Pooling
```typescript
const pool = new Pool({
  max: 20, // Maximum connections
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000
});
```

#### 2. Indexes
```sql
-- Add indexes for frequent queries
CREATE INDEX idx_leads_status_created 
ON leads(status, created_at DESC);

-- Composite index for filtering + sorting
CREATE INDEX idx_events_cycle_time 
ON events(cycle_id, start_time);
```

#### 3. Query Optimization
```sql
-- Use EXPLAIN ANALYZE
EXPLAIN ANALYZE SELECT * FROM leads 
WHERE status = 'new' 
ORDER BY created_at DESC LIMIT 20;

-- Add covering indexes
CREATE INDEX idx_leads_list 
ON leads(status, created_at, first_name, last_name, email);
```

### Caching Strategy:

#### 1. Redis Cache
```typescript
// Cache frequently accessed data
const getLeadStats = async () => {
  const cached = await cache.get('lead_stats');
  if (cached) return JSON.parse(cached);
  
  const stats = await query('SELECT ...');
  await cache.set('lead_stats', JSON.stringify(stats), 300); // 5 min
  return stats;
};
```

#### 2. Cache Invalidation
```typescript
// Invalidate on update
const updateLead = async (id, data) => {
  await query('UPDATE leads SET ... WHERE id = $1', [id]);
  await cache.del('lead_stats');
  await cache.del(`lead_${id}`);
};
```

### File Storage:
```typescript
// For production - use cloud storage
import AWS from 'aws-sdk';

const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY,
  secretAccessKey: process.env.AWS_SECRET_KEY
});

// Upload file
await s3.upload({
  Bucket: 'clubrrrr-uploads',
  Key: `avatars/${userId}.jpg`,
  Body: fileBuffer
}).promise();
```

---

## 🚀 Deployment <a name="deployment"></a>

### Production Checklist:

#### Environment Variables
```bash
✅ NODE_ENV=production
✅ Strong JWT secrets
✅ Database credentials
✅ Redis password
✅ SMTP settings
✅ CORS origin
```

#### Database
```bash
✅ Backups configured
✅ SSL connection
✅ Monitoring enabled
✅ Connection pooling
```

#### Security
```bash
✅ HTTPS enabled
✅ Rate limiting active
✅ Helmet configured
✅ Input validation
✅ Error messages sanitized
```

#### Performance
```bash
✅ Compression enabled
✅ Caching configured
✅ Indexes created
✅ CDN for static assets
```

#### Monitoring
```bash
✅ Error tracking (Sentry)
✅ Performance monitoring
✅ Log aggregation
✅ Uptime monitoring
```

### CI/CD Pipeline:
```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Run tests
        run: npm test
      - name: Build
        run: npm run build
      - name: Deploy
        run: |
          ssh user@server 'cd /var/www/clubrrrr && \
          git pull && \
          npm install && \
          npm run build && \
          pm2 restart clubrrrr-api'
```

---

## 📊 Monitoring & Analytics

### Logging Strategy:
```typescript
logger.info('User logged in', { userId, email });
logger.warn('High memory usage', { usage: process.memoryUsage() });
logger.error('Database error', { error, query });
```

### Metrics to Track:
- Response times
- Error rates
- Active users
- API usage
- Database performance
- Memory usage
- CPU usage

---

**המערכת מוכנה להרחבה ולפיתוח נוסף! 🚀**
