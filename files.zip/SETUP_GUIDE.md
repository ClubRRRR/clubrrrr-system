# 🎓 ClubRRRR Management System - מדריך התקנה מלא

## 📋 תוכן עניינים
1. [סקירה כללית](#overview)
2. [דרישות מערכת](#requirements)
3. [התקנה מקומית](#local-setup)
4. [הגדרת Database](#database-setup)
5. [הרצת המערכת](#running)
6. [Deployment לפרודקשן](#deployment)
7. [ארכיטקטורה](#architecture)
8. [API Documentation](#api-docs)
9. [תכונות המערכת](#features)
10. [פיתוח עתידי](#future)

---

## 🎯 סקירה כללית <a name="overview"></a>

ClubRRRR Management System היא מערכת ניהול מקצועית ומלאה למכללת נדל"ן, הכוללת:

### מודולים עיקריים:
- **CRM מלא** - ניהול לידים, עסקאות ומעקב מכירות
- **ניהול מחזורים** - קלאבר 360 ומנטורינג
- **לוח שנה + Gantt** - תכנון ומעקב אחר אירועים
- **ניהול משימות** - tasks ו-subtasks
- **מערכת פיננסית** - הכנסות והוצאות
- **פורטל תלמידים** - גישה אישית לכל תלמיד
- **מערכת הרשאות** - תפקידים שונים (Admin, Manager, Staff, Student)

### טכנולוגיות:
- **Backend**: Node.js + Express + TypeScript
- **Database**: PostgreSQL 14+ + Redis
- **Frontend**: React + TypeScript + Tailwind CSS (לבניה)
- **Real-time**: Socket.io
- **Authentication**: JWT + Refresh Tokens
- **Deployment**: Docker + Docker Compose

---

## 💻 דרישות מערכת <a name="requirements"></a>

### תוכנות נדרשות:
```bash
- Node.js v18+ 
- PostgreSQL 14+
- Redis 6+
- npm או yarn
- Git
```

### אופציונלי (לפרודקשן):
```bash
- Docker + Docker Compose
- Nginx
- SSL Certificate (Let's Encrypt)
```

---

## 🚀 התקנה מקומית <a name="local-setup"></a>

### שלב 1: הורדת הקוד
```bash
# חלץ את קובץ ה-tar.gz
tar -xzf clubrrrr-system.tar.gz
cd clubrrrr-system
```

### שלב 2: התקנת Backend
```bash
cd backend
npm install

# העתק את .env.example ל-.env וערוך את ההגדרות
cp .env.example .env
nano .env
```

### שלב 3: הגדרת משתני סביבה (.env)
```env
# חובה לשנות!
PORT=5000
NODE_ENV=development

DB_HOST=localhost
DB_PORT=5432
DB_NAME=clubrrrr
DB_USER=postgres
DB_PASSWORD=YOUR_STRONG_PASSWORD

REDIS_HOST=localhost
REDIS_PORT=6379

JWT_SECRET=YOUR_SUPER_SECRET_JWT_KEY_CHANGE_THIS
JWT_REFRESH_SECRET=YOUR_SUPER_SECRET_REFRESH_KEY_CHANGE_THIS

# הגדרות Email (Gmail example)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASSWORD=your_app_password
```

---

## 🗄️ הגדרת Database <a name="database-setup"></a>

### התקנת PostgreSQL
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install postgresql postgresql-contrib

# macOS
brew install postgresql
brew services start postgresql

# Windows
# הורד את ההתקנה מ: https://www.postgresql.org/download/windows/
```

### יצירת Database
```bash
# התחבר ל-PostgreSQL
sudo -u postgres psql

# צור משתמש ו-database
CREATE DATABASE clubrrrr;
CREATE USER clubrrrr_user WITH PASSWORD 'your_strong_password';
GRANT ALL PRIVILEGES ON DATABASE clubrrrr TO clubrrrr_user;
\q
```

### הרצת Schema
```bash
# מתיקיית database/
psql -U clubrrrr_user -d clubrrrr -f schema.sql
```

### התקנת Redis
```bash
# Ubuntu/Debian
sudo apt install redis-server
sudo systemctl start redis

# macOS
brew install redis
brew services start redis

# Windows
# הורד מ: https://github.com/microsoftarchive/redis/releases
```

---

## ▶️ הרצת המערכת <a name="running"></a>

### Development Mode
```bash
# Terminal 1 - Backend
cd backend
npm run dev

# Terminal 2 - Frontend (כשנבנה)
cd frontend
npm start
```

### המערכת תרוץ ב:
- Backend API: http://localhost:5000
- Frontend: http://localhost:3000 (כשנבנה)

### בדיקת Health
```bash
curl http://localhost:5000/health
```

תקבל:
```json
{
  "status": "OK",
  "timestamp": "2025-10-15T...",
  "environment": "development"
}
```

---

## 🌐 Deployment לפרודקשן <a name="deployment"></a>

### אופציה 1: Docker (מומלץ)

#### יצירת Dockerfile
```dockerfile
# backend/Dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

EXPOSE 5000

CMD ["node", "dist/server.js"]
```

#### Docker Compose
```yaml
# docker-compose.yml
version: '3.8'

services:
  postgres:
    image: postgres:14-alpine
    environment:
      POSTGRES_DB: clubrrrr
      POSTGRES_USER: clubrrrr_user
      POSTGRES_PASSWORD: your_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./database/schema.sql:/docker-entrypoint-initdb.d/schema.sql
    ports:
      - "5432:5432"

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  backend:
    build: ./backend
    environment:
      NODE_ENV: production
      DB_HOST: postgres
      REDIS_HOST: redis
    ports:
      - "5000:5000"
    depends_on:
      - postgres
      - redis

volumes:
  postgres_data:
```

#### הרצה עם Docker
```bash
docker-compose up -d
```

### אופציה 2: שרת Linux (AWS/GCP/Azure)

#### התקנה על Ubuntu 22.04
```bash
# עדכון מערכת
sudo apt update && sudo apt upgrade -y

# התקנת Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# התקנת PostgreSQL & Redis
sudo apt install -y postgresql postgresql-contrib redis-server

# התקנת PM2 לניהול תהליכים
sudo npm install -g pm2

# העתקת הקוד
cd /var/www
git clone your-repo-url clubrrrr
cd clubrrrr/backend

# התקנת dependencies
npm ci --only=production

# בניית TypeScript
npm run build

# הרצה עם PM2
pm2 start dist/server.js --name clubrrrr-api
pm2 save
pm2 startup
```

#### Nginx Reverse Proxy
```nginx
# /etc/nginx/sites-available/clubrrrr
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

```bash
# הפעלת הקונפיגורציה
sudo ln -s /etc/nginx/sites-available/clubrrrr /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

#### SSL עם Let's Encrypt
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

---

## 🏗️ ארכיטקטורה <a name="architecture"></a>

### מבנה הפרויקט
```
clubrrrr-system/
├── backend/
│   ├── src/
│   │   ├── config/         # Database, Redis, etc.
│   │   ├── controllers/    # Business logic
│   │   ├── routes/         # API endpoints
│   │   ├── middleware/     # Auth, error handling
│   │   ├── models/         # Data models
│   │   ├── services/       # Business services
│   │   ├── utils/          # Helper functions
│   │   └── server.ts       # Entry point
│   ├── logs/               # Application logs
│   ├── uploads/            # File uploads
│   └── package.json
│
├── frontend/               # React app (לבניה)
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── services/
│   │   ├── hooks/
│   │   ├── utils/
│   │   └── App.tsx
│   └── package.json
│
└── database/
    └── schema.sql          # Database schema
```

### Database Schema
```
Users & Auth:
- users
- refresh_tokens

CRM:
- leads
- lead_activities
- deals

Programs:
- programs
- cycles
- enrollments

Calendar:
- events
- event_attendees

Tasks:
- tasks
- task_comments
- task_attachments

Finance:
- expenses
- income

System:
- notifications
- audit_logs
```

---

## 📚 API Documentation <a name="api-docs"></a>

### Authentication Endpoints

#### POST /api/auth/register
```json
Request:
{
  "email": "user@example.com",
  "password": "password123",
  "firstName": "John",
  "lastName": "Doe",
  "phone": "0501234567",
  "role": "student"
}

Response:
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "user": { ... },
    "accessToken": "...",
    "refreshToken": "..."
  }
}
```

#### POST /api/auth/login
```json
Request:
{
  "email": "user@example.com",
  "password": "password123"
}

Response:
{
  "success": true,
  "data": {
    "user": { ... },
    "accessToken": "...",
    "refreshToken": "..."
  }
}
```

### Protected Endpoints
כל ה-API endpoints (מלבד auth) דורשים header:
```
Authorization: Bearer <accessToken>
```

### Leads Endpoints
- GET /api/leads - רשימת כל הלידים
- GET /api/leads/:id - ליד ספציפי
- POST /api/leads - יצירת ליד חדש
- PUT /api/leads/:id - עדכון ליד
- DELETE /api/leads/:id - מחיקת ליד
- POST /api/leads/:id/activity - הוספת פעילות
- GET /api/leads/stats/overview - סטטיסטיקות

### Cycles Endpoints
- GET /api/cycles - רשימת מחזורים
- POST /api/cycles - יצירת מחזור
- GET /api/cycles/:id/students - תלמידי מחזור
- POST /api/cycles/:id/enroll - רישום תלמיד

### Events Endpoints
- GET /api/events - רשימת אירועים
- POST /api/events - יצירת אירוע
- PUT /api/events/:id - עדכון אירוע
- DELETE /api/events/:id - מחיקת אירוע

### Tasks Endpoints
- GET /api/tasks - רשימת משימות
- POST /api/tasks - יצירת משימה
- PUT /api/tasks/:id - עדכון משימה
- POST /api/tasks/:id/subtask - הוספת תת-משימה

### Finance Endpoints
- GET /api/finance/income - הכנסות
- POST /api/finance/income - הוספת הכנסה
- GET /api/finance/expenses - הוצאות
- POST /api/finance/expenses - הוספת הוצאה
- GET /api/finance/dashboard - דשבורד פיננסי

---

## ✨ תכונות המערכת <a name="features"></a>

### ✅ מימושים קיימים:
1. **Authentication מלא** - JWT + Refresh Tokens
2. **Database Schema מלא** - כל הטבלאות והקשרים
3. **API Structure** - Routes, Controllers, Middleware
4. **Error Handling** - מערכת שגיאות מקצועית
5. **Logging** - Winston logger
6. **Security** - Helmet, CORS, Rate limiting
7. **Real-time** - Socket.io setup
8. **Caching** - Redis integration

### 🚧 לפיתוח (Frontend):
1. **Dashboard** - דף בית עם KPIs
2. **CRM Interface** - טפסים וטבלאות לידים
3. **Calendar View** - תצוגת לוח שנה
4. **Gantt Chart** - תכנון ויזואלי
5. **Tasks Board** - Kanban board
6. **Student Portal** - פורטל תלמידים
7. **Finance Dashboard** - גרפים ודוחות

---

## 🔮 פיתוח עתידי <a name="future"></a>

### Phase 1 - Frontend (שבועות 1-2)
- [ ] בניית React app
- [ ] דשבורד ראשי
- [ ] CRM interface
- [ ] Authentication UI

### Phase 2 - Core Features (שבועות 3-4)
- [ ] ניהול מחזורים
- [ ] לוח שנה + Gantt
- [ ] ניהול משימות
- [ ] פורטל תלמידים

### Phase 3 - Advanced Features (שבועות 5-6)
- [ ] מערכת פיננסית מלאה
- [ ] דוחות ואנליטיקס
- [ ] התראות בזמן אמת
- [ ] אינטגרציות (WhatsApp, Email)

### Phase 4 - Optimization (שבוע 7)
- [ ] Performance optimization
- [ ] Mobile responsive
- [ ] Security audit
- [ ] Documentation

---

## 🔐 אבטחה

### Best Practices המיושמות:
- ✅ Password hashing (bcrypt)
- ✅ JWT authentication
- ✅ Refresh token rotation
- ✅ SQL injection protection (Parameterized queries)
- ✅ XSS protection (Helmet)
- ✅ CORS configuration
- ✅ Rate limiting (מוכן)
- ✅ Input validation
- ✅ Audit logging

### המלצות נוספות:
- שנה את כל הסודות ב-.env
- השתמש ב-HTTPS בפרודקשן
- הגדר backups אוטומטיים
- עשה security audit תקופתי
- עדכן dependencies באופן קבוע

---

## 📞 תמיכה

### בעיות נפוצות:

**1. Database connection failed**
```bash
# בדוק שPostgreSQL רץ
sudo systemctl status postgresql

# בדוק credentials ב-.env
```

**2. Redis connection error**
```bash
# בדוק שRedis רץ
sudo systemctl status redis

# התחבר ידנית
redis-cli ping
```

**3. Port already in use**
```bash
# מצא תהליך שתופס את הפורט
lsof -i :5000

# הרוג את התהליך
kill -9 <PID>
```

---

## 📝 Logs

### מיקום Logs:
```
backend/logs/
├── combined.log      # All logs
├── error.log         # Errors only
├── exceptions.log    # Unhandled exceptions
└── rejections.log    # Promise rejections
```

### צפייה ב-Logs:
```bash
# Real-time
tail -f backend/logs/combined.log

# Errors only
tail -f backend/logs/error.log
```

---

## 🎓 קרדיטים

**ClubRRRR Management System**  
נבנה על ידי: Claude  
גרסה: 1.0.0  
תאריך: אוקטובר 2025  

---

## 📄 רישיון

MIT License - חופשי לשימוש ושינוי.

---

**🚀 בהצלחה עם המערכת החדשה! 🎉**
